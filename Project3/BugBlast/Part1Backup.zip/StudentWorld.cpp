#include "StudentWorld.h"
#include "Actor.h"

GameWorld* createStudentWorld()
{
	return new StudentWorld();
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
StudentWorld::~StudentWorld()
{
    itr = actorList.begin();
    while(itr != actorList.end())
    {
        delete (*itr);
        itr = actorList.erase(itr);
    }
    delete playerPtr;
}

int StudentWorld::init()
{

    std::string curLevel = "level00.dat";  // Step 2
    int l_num = getLevel();
    if (l_num < 10) 
        curLevel[6] = l_num + '0';
    else                              //2 digit number 
    {   
        curLevel[5] = (l_num / 10) + '0';  //Tens digit
        curLevel[6] = (l_num % 10) + '0';  //Ones digit
    }

    Level::LoadResult result = m_level.loadLevel(curLevel);

    if (l_num == 0 && result == Level::load_fail_file_not_found) //First level cannot be found
        return GWSTATUS_NO_FIRST_LEVEL; 
    if (l_num != 0 && result == Level::load_fail_file_not_found) //Player won
        return GWSTATUS_PLAYER_WON;
    if (result == Level::load_fail_bad_format)                   //Improper format level
        return GWSTATUS_LEVEL_ERROR;

// enum MazeEntry {
//     empty, exit, player, simple_zumi, complex_zumi, perma_brick, destroyable_brick
// };
    Level::MazeEntry item;
    for (int x = 0; x < VIEW_WIDTH; x++)
    {
        for (int y = 0; y < VIEW_HEIGHT; y++)
        {
            item = m_level.getContentsOf(x,y);

            if      (item == Level::empty)
                continue;
            else if (item == Level::perma_brick)
                actorList.push_back(new PermaBrick(x,y));             
            else if (item == Level::destroyable_brick)
                actorList.push_back(new DestroyableBrick(x,y));
            else if (item == Level::player)
                playerPtr = new Player(x,y, this);
        }
    }

	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    playerPtr->doSomething();
    for (itr = actorList.begin(); itr != actorList.end(); itr++)
    {
        if (!((*itr)->isDead()))
            (*itr)->doSomething();
        if (playerPtr->isDead())
            return GWSTATUS_PLAYER_DIED;
    }
    if (playerPtr->isDead())
        return GWSTATUS_PLAYER_DIED;

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    itr = actorList.begin();
    while(itr != actorList.end())
    {
        delete *itr;
        itr = actorList.erase(itr);
    }
    delete playerPtr;
}
