#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Level.h"
#include <list>
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class Actor;
class Player;


class StudentWorld : public GameWorld
{
public:
    StudentWorld() : GameWorld(){}
    ~StudentWorld();
    //Accessors
    Level* getLevelPtr() {return &m_level;}

    //Mutators
	virtual int init();                    //Page 14
	virtual int move();
	virtual void cleanUp();



private:
    std::list<Actor*> actorList; 
    std::list<Actor*>::iterator itr;
    Player* playerPtr;
    Level m_level;
};

#endif // STUDENTWORLD_H_
