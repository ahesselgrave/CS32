#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"


// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY): GraphObject(imageID, startX, startY) {setVisible(true);}
	virtual void doSomething()  = 0;
	virtual void setDead()      = 0;
	virtual bool isDead() const = 0;
private:


};

class Movable : public Actor      //All movable actors can die: Zumis and Players, and all moving objects need to know the level layout
{
public:
	Movable(int imageID, int startX, int startY, StudentWorld* world): Actor(imageID, startX, startY){}

private:

};

class Player : public Movable
{
public:
	Player(int startX, int startY, StudentWorld* world)
		: Movable(IID_PLAYER, startX, startY, world), m_numSpray(2), canWalkThruDestroyableBricks(false), m_dead(false), m_world(world){}
	virtual ~Player(){}
	//Accessors
	virtual bool isDead() const {return m_dead;}
	StudentWorld* getWorld() const {return m_world;}
	//Mutators
	virtual void setDead() {m_dead = true;}
	virtual void doSomething();
	


private:
	int m_numSpray;
	bool canWalkThruDestroyableBricks;
	bool m_dead;
	StudentWorld* m_world;
};

class Immovable : public Actor
{
public:
	Immovable(int imageID, int startX, int startY): Actor(imageID, startX, startY){}

private:

};

class Brick : public Immovable
{
public:
	Brick(int imageID, int startX, int startY): Immovable(imageID, startX, startY){}

private:
};

class PermaBrick : public Brick
{
public:
	PermaBrick(int startX, int startY): Brick(IID_PERMA_BRICK, startX, startY) {}
	virtual ~PermaBrick(){}
	virtual void setDead(){}
	virtual void doSomething(){}
	virtual bool isDead() const {return false;}

private:
};

class DestroyableBrick : public Brick
{
public:
	DestroyableBrick(int startX, int startY): Brick(IID_DESTROYABLE_BRICK, startX, startY) {}
	virtual ~DestroyableBrick(){}
	virtual void setDead(){}
	virtual void doSomething(){}
	virtual bool isDead() const {return false;}
};

#endif // ACTOR_H_
