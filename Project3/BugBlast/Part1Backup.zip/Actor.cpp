#include "Actor.h"
#include "StudentWorld.h"
#include "Level.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
void Player::doSomething()
{
	if(isDead())
		return;

	int ch;
	if (m_world->getKey(ch))
	{
		int x = getX();
		int y = getY();
		switch(ch)
		{
			case KEY_PRESS_UP:
				if (m_world->getLevelPtr()->getContentsOf(x, y + 1) != Level::perma_brick && m_world->getLevelPtr()->getContentsOf(x, y + 1) != Level::destroyable_brick)
					moveTo(x, y + 1);
				break;
			case KEY_PRESS_LEFT:
				if (m_world->getLevelPtr()->getContentsOf(x - 1, y) != Level::perma_brick && m_world->getLevelPtr()->getContentsOf(x - 1, y) != Level::destroyable_brick)
					moveTo(x - 1, y);
				break;
			case KEY_PRESS_DOWN:
				if (m_world->getLevelPtr()->getContentsOf(x, y - 1) != Level::perma_brick && m_world->getLevelPtr()->getContentsOf(x, y - 1) != Level::destroyable_brick)
					moveTo(x, y - 1);
				break;
			case KEY_PRESS_RIGHT:
				if (m_world->getLevelPtr()->getContentsOf(x + 1, y) != Level::perma_brick && m_world->getLevelPtr()->getContentsOf(x + 1, y) != Level::destroyable_brick)
					moveTo(x + 1, y);
				break;
			default:
				break;
		}
	}
}